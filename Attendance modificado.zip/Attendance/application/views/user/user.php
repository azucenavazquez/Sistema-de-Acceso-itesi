<div class="container">
    <h2>Usuarios</h2>
    <hr>

    <div class="table-responsive">
        <table id="data-table">
            <thead>
                <tr>
                    <th>
                        No.
                    </th>
                    <th>
                        Nombre
                    </th>
                    <th>
                        Apellido
                    </th>
                    <th>
                        No. Control
                    </th>
                    <th>
                        Carrera
                    </th>
                    <th>
                        Correo
                    </th>
                    <th>
                        Semestre
                    </th>
                    <th>
                        Último Acceso
                    </th>
                    <th>
                        Rol
                    </th>
                    <th>
                        Estado
                    </th>
                    <th>
                        Baneado
                    </th>
                    <th>
                        Acción
                    </th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <p>
        <b>*Nota</b> : <br>
        Estado "pendiente" significa que el usuario no ha verifica su correo electrónico.
    </p>
</div>

</div><!--row-->
